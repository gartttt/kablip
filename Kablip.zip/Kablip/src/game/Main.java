package game;

//import java.awt.Canvas;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.MouseInfo;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.AttributedString;
import java.util.ArrayList;
import java.util.Arrays;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;
import java.awt.font.TextAttribute;

//Represents the JPanel where everything is drawn
public class Main extends JPanel{
		
	private static JFrame window;
	private static Color bgColor;
	private static BufferedImage titleImage;
	
	//The game state is stored in the gameState variable and is changed to different constants. 
	private static String gameState;
	public static final String GAME = "game";
	public static final String GAME_OVER = "game over";
	public static final String MENU = "menu";
	public static final String HELP = "help";
	//Variable storing instructions
	private static final String[] INSTRUCTIONS = {"How to play: ","You play as the green tank.","Click and aim to shoot the blue squares.","If they touch you, you will lose health", "until you die. (Click EXIT for menu)"};
	private static Dimension screenSize;
	//May be used in the future for calculating font size
//	private static final Canvas CANVAS = new Canvas();
	
	private static Main gameScreen;
	private static Graphics2D g2d;
	private static int ticks;
	private static double [] timers;
	private static int score;
	private static int highScore;
	private static double spawnInterval = 10;

	private static int mouseX;
	private static int mouseY;
	private static int cursor;
	
	private static Player player;
	private static ArrayList<Bullet> playerBullets;
	private static ArrayList<Enemy> enemies;
	
	private static GameButton playButton;
	private static GameButton helpButton;
	private static GameButton exitButton;
	private static GameButton retryButton;
	
	private static boolean init = true;
	
	public Main() {
		try {
			titleImage = ImageIO.read(new File("images/kablip.png"));
		} catch (IOException e) {
			System.out.println("Failed to load image!");
			System.out.println(e);
		} 	
		
		
		//Close the window if the escape key is pressed.
		KeyListener listener= new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {}

			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
					window.dispatchEvent(new WindowEvent(window, WindowEvent.WINDOW_CLOSING));
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {}
		};
		addKeyListener(listener);
		setFocusable(true);
		
		//Updates the screen every 100th of a second.
		Timer timer = new Timer(10, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setBounds((int)percentWidth(50)-((int)percentHeight(150)/2), 0, (int)percentHeight(150),screenSize.height);
				repaint();
				if(init) {
					init = false;
				}
			}
		}); 
		timer.setInitialDelay(0);
		timer.start();

	}
	
	//Displays the game on the JPanel
	public void paint(Graphics g) {
		super.paintComponent(g);
		
		//Attempts to make everything less pixelated
	    g2d = (Graphics2D) g;
	    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	    g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
	    
	    //Move exit button based on game state
    	if(gameState == GAME_OVER) {
			exitButton.setY(percentScreenHeight(50)+ 130);
		} else if(gameState == MENU) {
			exitButton.setY(percentScreenHeight(50)+ 210);
		}
	    
	    //Draw menu screen
	    if(gameState == MENU || gameState == HELP) {
	    	g2d.drawImage(titleImage, (int)percentScreenWidth(50)-(int)(percentScreenWidth(75)/2), 0, (int)percentScreenWidth(75), (int)percentScreenHeight(50), null);
	    	exitButton.draw(g2d);
	    	if(gameState == MENU) {
	    		playButton.draw(g2d);
		    	helpButton.draw(g2d);
	    	} else {
	    		g2d.setColor(Color.WHITE);
	    		for(int i = 0; i < INSTRUCTIONS.length; i++) {
	    			drawFormattedString(g2d, INSTRUCTIONS[i], (int)percentScreenWidth(7), (int)percentScreenHeight(45)+i*(int)percentScreenHeight(6), (int)percentScreenHeight(6));
	    		}
	    	}
	    } else if(gameState == GAME || gameState == GAME_OVER) {
	    	//Draws the screen
	    	
	    	//Makes sure the particles don't overlap the enemies when the player dies
	    	if(gameState == GAME_OVER) {
		    	player.draw(g2d);
	    	}
	    	
	    	//Spawns enemies
	    	if(ticks - timers[0] > spawnInterval * 100 && gameState == GAME) {
		    	enemies.add(new Enemy());
		    	timers[0] = ticks;
		    	spawnInterval =  spawnInterval/3 + 6.6666666666; //2.5 = spawnInterval/4 
		    	spawnInterval = 6.6666666666;
	    	}
	    	
	    	//Draws all bullets (made inefficient for while loop requirement)
		    int j = 0;
	    	while(j < playerBullets.size()) {
		    	playerBullets.get(j).draw(g2d);
		    	j++;
		    }
		    
		    //Check enemy collision and end the game if the player died
		    for(Enemy e: enemies.toArray(new Enemy[0])) {
		    	e.draw(g2d);
		    	if(gameState != GAME_OVER && player.collidesWith(e)) {
		    		enemies.remove(e);
		    		if(player.getIfDead()) {
		    			gameState = GAME_OVER;
			    		if(score > highScore) {
			    			highScore = score;
			    		}
			    		timers[1] = ticks;
			    		playSound("explosion_1.wav");
		    		} else {
		    			playSound("Explode.wav");
		    		}
		    	}
		    }
		    
		    //Check for bullet and enemy collisions
		    for(Bullet b: playerBullets.toArray(new Bullet[0])) {
		    	for(Enemy e: enemies.toArray(new Enemy[0])) {
		    		if(e.collidesWith(b)) {
		    			e.splitOrDie(enemies);
		    			playerBullets.remove(b);
		    			score++;
		    		}
		    	}
		    	if(b.getOffScreen()) {
		    		playerBullets.remove(b);
		    	}
		    }
		    
		    if(gameState == GAME_OVER){
		    	g2d.setColor(new Color(50/255F, 50/255F, 50/255F, Math.min((float)(ticks - timers[1])/200, 0.5F)));
		    	g2d.fillRect(0, 0, getGameWidth(), getGameHeight());
		    }
		    
		    //Draws the player so that bullets do not appear above the canon
		    if(gameState == GAME) {
		    	player.draw(g2d);
		    }else if(gameState == GAME_OVER && ticks - timers[1] >= 100) {
		    	//Draws retry button after 2 seconds so that the player doesn't accidentally click it
	    		g2d.setFont(new Font("", Font.PLAIN, 100));
	    		drawFormattedString(g2d, "Game Over", getGameWidth()/2-230, 200, g2d.getFont().getSize());
		    	retryButton.draw(g2d);
		    	exitButton.draw(g2d);
		    } 
		    
		    
	    	//Display Score
	    	g2d.setColor(Color.WHITE);
	    	g2d.setFont(new Font("", Font.PLAIN, 50));
	    	drawFormattedString(g2d, ""+score, getGameWidth() - (int)getFontWidth(score+"", g2d.getFont()), g2d.getFont().getSize(), 50);
	    	drawFormattedString(g2d, "HI:"+highScore, 0, g2d.getFont().getSize(), 50);
	    	
	    	
	    	
		    
		    
		    
		    
		   
	    }
	    
	    //Each tick is 10ms or 0.01
	    ticks++;
	}
	
	@Override
    public Dimension getPreferredSize() {
        return new Dimension((int)percentHeight(150), screenSize.height);
    }
	
	@Override
    public Dimension getMinimumSize() {
        return new Dimension((int)percentHeight(150), screenSize.height);
    }
	
	@Override
    public Dimension getMaximumSize() {
        return new Dimension((int)percentHeight(150), screenSize.height);
    }
	
	public static double percent(double value, double percent) {
		return (percent/100*value);
	}
	
	public static double percentWidth(double percent) {
		return percent(percent,screenSize.width);
	}
	
	public static double percentHeight(double percent) {
		return percent(percent,screenSize.height);
	}
	
	public static double percentScreenWidth(double percent) {
		return percent(percent,gameScreen.getWidth());
	}
	
	public static double percentScreenHeight(double percent) {
		return percent(percent,gameScreen.getHeight());
	}
	
	public static int getGameWidth() {
		return (int) gameScreen.getWidth();
	}
	
	public static int getGameHeight() {
		return (int) gameScreen.getHeight();
	}
	
	public static int getMouseX() {
		return mouseX;
	}
	
	public static int getMouseY() {
		return mouseY;
	}
	
	public static int getCursorVar() {
		return cursor;
	}
	
	public static void setCursorVar(int newCursor) {
		cursor = newCursor;
	}
	
	public static String getGameState() {
		return gameState;
	}
	
	public static void setTheCursor(Cursor cursor) {
		gameScreen.setCursor(cursor);
	}
	
	public void checkButtonHover() {
		
	}
	
	public static void onMouseMove() {
		mouseX = (int) MouseInfo.getPointerInfo().getLocation().getX() - gameScreen.getX();
  		mouseY = (int) MouseInfo.getPointerInfo().getLocation().getY() - gameScreen.getY();
  		if(gameState == GAME) {
  			gameScreen.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
  		}else {
  			gameScreen.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
  		}
  		
  		//Displays the buttons differently when the mouse hovers over them
  		playButton.isHover(gameState, true);
  		exitButton.isHover(gameState, ticks - timers[1] >= 200);
  		helpButton.isHover(gameState, true);
  		retryButton.isHover(gameState, ticks - timers[1] >= 200);
	}
	
	public static double getFontWidth(String text, Font f) {
//		return CANVAS.getFontMetrics(f).stringWidth(text);
		
		//Temporary fix to calculating font width since getfontmetrics isn't accurate.
		double returnValue = text.length() * f.getSize()*0.555;
		return returnValue;
	}
	
	//Draws formatted text
	public static void drawFormattedString(Graphics2D g2d, String text,  int x, int y, int fontSize) {
		g2d.setColor(Color.WHITE);
		g2d.setFont(new Font("Consolas", Font.PLAIN, fontSize));
		AttributedString aString = new AttributedString(text);
		aString.addAttribute(TextAttribute.FONT, g2d.getFont());
		g2d.drawString(aString.getIterator(), x, y);
	}
	
	//Plays a sound given the file name
	public static void playSound(String url) {
		try {
			Clip clip = AudioSystem.getClip();
	        AudioInputStream inputStream = AudioSystem.getAudioInputStream(new File("sounds/"+url));
	        clip.open(inputStream);
	        clip.start(); 
	        clip.addLineListener(new LineListener(){
	            @Override
	            public void update(LineEvent event)
	            {
	                if (event.getType() == LineEvent.Type.STOP)
	                    clip.close();
	            }
	        });
        } catch (Exception e) {
        	e.printStackTrace();
        }
	}
	
	//Resets variables to default values
	public static void gameInit() {
		player = new Player();
		playerBullets = new ArrayList<Bullet>();
		enemies = new ArrayList<Enemy>();
		timers = new double[2];
		for(int i = 0; i < timers.length; i++) {
			timers[i] = Integer.MIN_VALUE;
		}
		score = 0;
		spawnInterval = 10;
	}
	
	public static void main(String[] args) {
		//Initializes the JPanel where the game is drawn.
		ticks = 0;
		gameState = MENU;
		screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		gameScreen = new Main();
		
		
		//Invoke later makes sure that the window is displayed properly
		gameInit();
		SwingUtilities.invokeLater(new Runnable() {
	        @Override
	        public void run() {
	        	//Creates the window and formats it properly
	    		window = new JFrame("Kablip");
	    		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    		window.setExtendedState(JFrame.MAXIMIZED_BOTH); 
	    		window.setUndecorated(true);
	    		window.setVisible(true);
	    		window.setResizable(false);
	    		window.setBackground(new Color(0, 0, 0));
	    		window.getContentPane().setBackground(new Color(0, 0, 0));
	    		window.setVisible(true);
	    		bgColor = new Color(255,0,255);
	    		window.add(gameScreen);
	    		window.setSize(screenSize.width, screenSize.height);	
	    		gameScreen.repaint();
	    		window.addMouseListener(new MouseListener() {

	    			@Override
	    			public void mouseClicked(MouseEvent e) {
	    				
	    			}

	    			@Override
	    			public void mousePressed(MouseEvent e) {
	    				//Checks for click on button and in game for shooting
	    				if(e.getButton() == MouseEvent.BUTTON1) {
	    					if(gameState == GAME) {
		    					playerBullets.add(new Bullet());
		    					playSound("shoot.wav");
		    				}
	    					playButton.checkClick(gameState, true);
	    					helpButton.checkClick(gameState, true);
	    					exitButton.checkClick(gameState, true);
	    					retryButton.checkClick(gameState, ticks - timers[1] >= 200);
	    				}
	    			}

	    			@Override
	    			public void mouseReleased(MouseEvent e) {
	    				
	    			}

	    			@Override
	    			public void mouseEntered(MouseEvent e) {
	    			}

	    			@Override
	    			public void mouseExited(MouseEvent e) {
	    			}
	    			
	    		});
	    		window.addMouseMotionListener(new MouseMotionListener() {
					@Override
					public void mouseDragged(MouseEvent e) {
						onMouseMove();
					}

					@Override
					public void mouseMoved(MouseEvent e) {
						onMouseMove();
					}
	    		});
	    		gameScreen.setBackground(bgColor);
	    		//Initializes all the buttons
	    		playButton = new GameButton("PLAY", percentScreenWidth(50), percentScreenHeight(50), 75, Arrays.asList(MENU).toArray(new String[1]), g2d) {
	    			@Override
	    			public void onClick(boolean condition) {
	    				gameInit();
    					Main.gameState = GAME;
	    			}
	        	};
	        	helpButton = new GameButton("HELP", percentScreenWidth(50), percentScreenHeight(50)+ 85, 75, Arrays.asList(MENU).toArray(new String[1]), g2d) {
	    			@Override
	    			public void onClick(boolean condition) {
	    				Main.gameState = HELP;
	    			}
	        	};
	        	exitButton = new GameButton("EXIT", percentScreenWidth(50), percentScreenHeight(50)+ 170, 75,Arrays.asList(MENU, HELP, GAME_OVER).toArray(new String[3]), g2d) {
	    			@Override
	    			public void onClick(boolean condition) {
	    				if(gameState == MENU) {
	    					window.dispatchEvent(new WindowEvent(window, WindowEvent.WINDOW_CLOSING));
	    				} else if(gameState == HELP || gameState == GAME_OVER) {
	    					Main.gameState = MENU;
	    				}
	    			}
	        	};
	        	retryButton = new GameButton("RETRY?", percentScreenWidth(50), percentScreenHeight(50), 75, Arrays.asList(GAME_OVER).toArray(new String[1]), g2d) {
	    			@Override
	    			public void onClick(boolean condition) {
	    				if(condition) {
	    					gameInit();
	    					Main.gameState = GAME;
	    				}
	    			}
	        	};
	        	
	        }
	    });
	}
	

}
