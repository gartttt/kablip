package game;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ArrayList;

public class Enemy extends Entity{
	
	private static final int TOP_SIDE = 0;
	private static final int BOTTOM_SIDE = 1;
	private static final int LEFT_SIDE = 2;
	private static final int RIGHT_SIDE = 3;
	
	private static final double START_SIZE = Main.percentScreenWidth(15);
	public static final int MAX_SPLITS = 3;//3
	private static final int NUM_PIECES = 3;//3
	private static final double SPEED_MULTIPLIER = 0.4;//0.3
	
	private int enemyLevel;
	private double aimX;
	private double aimY;
	private double dx;
	private double dy;
	private double xv;
	private double yv;
	private double direction;
	private double speed;
	private int side;
	private boolean bounceLeftRight;
	private boolean bounceUpDown;
	
	public Enemy() {
		super(START_SIZE, new Color(0, 0, 255));
		enemyLevel = 0;
		
		//Make enemy go to random place off screen when spawned
		side = (int)(Math.random()*4);
		if(side == TOP_SIDE) {
			setX((int)(Math.random()*(Main.getGameWidth()-getWidth())));
			setY(-getHeight());
		} else if(side == BOTTOM_SIDE) {
			setX((int)(Math.random()*(Main.getGameWidth()-getWidth())));
			setY(Main.getGameHeight());
		} else if(side == LEFT_SIDE) {
			setX(-getWidth());
			setY((int)(Math.random()*(Main.getGameHeight()-getHeight())));
		} else if(side == RIGHT_SIDE) {
			setX(Main.getGameWidth());
			setY((int)(Math.random()*(Main.getGameHeight()-getHeight())));
		}
		
		//Setup so that the enemy is constantly moving towards the player (center of the screen).
		aimX = Main.percentScreenWidth(50) - getWidth()/2;
		aimY = Main.percentScreenHeight(50) - getHeight()/2;
		speed = SPEED_MULTIPLIER;
		dx = aimX - getX();
		dy = aimY - getY();
		direction = Math.atan2(dy, dx);
		xv = (double)(speed * Math.cos(direction));
		yv = (double)(speed * Math.sin(direction));
	}
	
	public Enemy(int enemyLevel, double startX, double startY, int side) {
		super(startX, startY, Main.percentScreenWidth(15)/(enemyLevel+1), new Color(0, 0, 255));
		this.enemyLevel = enemyLevel;
		this.side = side;
		
		speed = SPEED_MULTIPLIER * (enemyLevel + 1);
		
		//Makes sure that if the parent enemy is shot behind the screen that it doesn't choose a direction to move away from the player
		if(side == -1) {
			direction = Math.random() * 2 * Math.PI;
			bounceLeftRight = true;
			bounceUpDown = true;
		} else if(side == TOP_SIDE){
			direction = Math.random() * Math.PI;
			bounceLeftRight = true;
			bounceUpDown = false;
		} else if(side == BOTTOM_SIDE){
			direction = Math.random() * Math.PI + Math.PI;
			bounceLeftRight = true;
			bounceUpDown = false;
		} else if(side == LEFT_SIDE){
			direction = Math.random() * Math.PI + 3 * Math.PI / 2;
			bounceLeftRight = false;
			bounceUpDown = true;
		} else if(side == RIGHT_SIDE){
			direction = Math.random() * Math.PI + Math.PI / 2;
			bounceLeftRight = false;
			bounceUpDown = true;
		}
		
		xv = (double)(speed * Math.cos(direction));
		yv = (double)(speed * Math.sin(direction));
		
	}
	
	@Override
	public void draw(Graphics2D g) {
		g.setColor(getColor());
		g.fill(new Rectangle.Double(getX(), getY(), getWidth(), getHeight()));
		
		//Bouncing off edges is disabled where the enemy is trying to enter until the enemy is fully displayed on the screen
		bounceLeftRight = !offScreen() ? true : bounceLeftRight;
		bounceUpDown = !offScreen() ? true : bounceUpDown;
		
		bounceIfOnEdge();

		setX((getX() + xv));
		setY((getY() + yv));
		
		
	}
	
	public double getLevel() {
		return enemyLevel;
	}
	
	public boolean collidesWith(Bullet b) {
		return (b.getX() - b.getRadius() <= getX() + getWidth() && b.getX() + b.getRadius() >= getX() && b.getY() - b.getRadius() <= getY() + getHeight() && b.getY() + b.getRadius() >= getY());
	}
	
	public boolean offScreen() {
		return offScreenLeft() || offScreenDown() || offScreenRight() || offScreenUp();
	}
	
	public boolean offScreenLeft() {
		return getX() < 0;
	}
	
	public boolean offScreenRight() {
		return getX() + getWidth() > Main.getGameWidth() ;
	}
	
	public boolean offScreenUp() {
		return getY() + getHeight() > Main.getGameHeight();
	}
	
	public boolean offScreenDown() {
		return getY() < 0 ;
	}
	
	public void bounceIfOnEdge() {
		if(bounceLeftRight) {
			if(offScreenLeft() || offScreenRight()) {
				direction = Math.PI - direction < 0 ? Math.PI - direction + 2 * Math.PI : Math.PI - direction;
				xv = (double)(speed * Math.cos(direction));
				yv = (double)(speed * Math.sin(direction));
				bounceLeftRight = false;
			}
		}
		if(bounceUpDown) {
			if(offScreenUp() || offScreenDown()) {
				direction = Math.PI * 2 - direction < 0 ? Math.PI * 2 - direction + 2 * Math.PI : Math.PI * 2 - direction;
				xv = (double)(speed * Math.cos(direction));
				yv = (double)(speed * Math.sin(direction));
				bounceUpDown = false;
			}
		}
	}
	
	//Will create smaller enemies of itself after dying unless the enemies are small enough. Think of slimes in Minecraft.
	public void splitOrDie(ArrayList<Enemy> enemies) {
		if(enemyLevel != MAX_SPLITS) {
			if(offScreen()) {
				for(int i = 0; i < NUM_PIECES; i++) {
					enemies.add(new Enemy(enemyLevel + 1, getX() + getWidth()/2, getY() + getHeight()/2, side));	
				}
			} else {
				for(int i = 0; i < NUM_PIECES; i++) {
					enemies.add(new Enemy(enemyLevel + 1, getX() + getWidth()/2, getY() + getHeight()/2, -1));	
				}
			}
			Main.playSound("hit 2.wav");
		} else {
			Main.playSound("hit 1.wav");
		}
		enemies.remove(this);
	}
}
