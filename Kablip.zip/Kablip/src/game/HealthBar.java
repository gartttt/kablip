package game;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class HealthBar extends Entity{
	
	private double percentage;
	private boolean label;
	
	public HealthBar(double percentage, double x, double y, double width) {
		super(x, y, width, width/4);
		this.percentage = percentage;
	}
	
	public HealthBar(double percentage, double x, double y, double width, double height) {
		super(x, y, width, height);
		this.percentage = percentage;
	}
	
	public HealthBar(double percentage, double x, double y, double width, double height, boolean label) {
		super(x, y, width, height);
		this.percentage = percentage;
		this.label = label;
	}

	//The health bar is represented by drawing a rectangle the width of the value and another rectangle with a width of 1-value
	@Override
	public void draw(Graphics2D g) {
		double barX = getX();
		g.setColor(new Color(0F, 255/255F, 0F, 0.9F));
		g.fill(new Rectangle.Double(barX, getY(), getWidth() * percentage, getHeight()));
		g.setColor(new Color(255/255F, 0, 0F, 0.9F));
		g.fill(new Rectangle.Double(barX + getWidth() * percentage, getY(), getWidth() * (1 - percentage), getHeight()));
		//Draws the number of health points within the bar optionally
		if(label) {
			Main.drawFormattedString(g, "HP: "+(percentage*100), (int)(getX()), (int)(getY() + getHeight()*5/6), (int)(getHeight()));
		}
	}
}
