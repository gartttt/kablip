package game;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

//Particles that display when the player dies
public class PlayerParticle extends Entity{
	
	private double speed;
	private final double MULTIPLIER = 0.99;
	private double direction;
	
	public PlayerParticle() {
		super(0, new Color(0, 255, 0));
		setX(Main.percentScreenWidth(50)-Main.percentScreenWidth(1)/2);
		setY(Main.percentScreenHeight(50)-Main.percentScreenWidth(1)/2);
		setWidth(Main.percentScreenWidth(1));
		setHeight(Main.percentScreenWidth(1));
		
		direction = Math.random() * 2 * Math.PI;
		speed = 3 * Math.random();
	}

	@Override
	public void draw(Graphics2D g) {
		g.setColor(getColor());
		g.fill(new Rectangle.Double(getX()-getWidth()/2, getY()-getHeight()/2, getWidth(), getHeight()));
		
		double xv = (double)(speed * Math.cos(direction));
		double yv = (double)(speed * Math.sin(direction));

		setX((getX() + xv));
		setY((getY() + yv));
		
		speed *= MULTIPLIER; 
	}
}
