package game;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;

//Represents bullets shot out by player
public class Bullet extends Entity{
	
	private final int SPEED = 8;//6
	private final double SIZE = Main.percentScreenHeight(4.5);
	
	private double aimX;
	private double aimY;
	private double dx;
	private double dy;
	private double direction;
	private boolean offScreen;
	
	public Bullet() {
		//5
		super((int)Main.percentScreenWidth(50), (int)Main.percentScreenHeight(50), new Color(0, 255, 255));
		
		//Sets direction to move based on mouse position
		setWidth(SIZE);
		setHeight(SIZE);
		
		aimX = Main.getMouseX();
		aimY = Main.getMouseY();
		
		dx = aimX - getX();
		dy = aimY - getY();

		direction = Math.atan2(dy, dx);
		
	}
	
	@Override
	public void draw(Graphics2D g) {
		g.setColor(getColor());
		
		double shootAngle = -direction - Math.PI/2;	
		if (shootAngle < 0) {
			shootAngle += Math.PI * 2;
		}
		
		//Make the bullets rotate to point in the direction they are going
		AffineTransform oldTransform = g.getTransform();
		AffineTransform newTransform = g.getTransform();
		newTransform.translate(0, 0);
		newTransform.rotate(direction, getX(), getY());
		g.setTransform(newTransform);
		//Commented lines are for collision and rotation debugging
//		g.drawRect(0, 0, Main.getGameWidth(), Main.getGameHeight());
		g.fill(new Rectangle.Double(getX()-getWidth()/2, getY()-getHeight()/2, getWidth(), getHeight()));
		g.setTransform(oldTransform);
		
		double xv = (double)(SPEED * Math.cos(direction));
		double yv = (double)(SPEED * Math.sin(direction));

		setX((getX() + xv));
		setY((getY() + yv));
		
		offScreen = getX() + getRadius() < 0 || getX() > Main.getGameWidth() + getRadius() || getY() + getRadius() < 0 || getY() > Main.getGameHeight() + getRadius();
		
	}
	
	public void testDraw(Graphics2D test) {
		test.setColor(getColor());
		test.fill(new Rectangle.Double(0.01, getY(), getWidth(), getHeight()));
	}
	
	public boolean getOffScreen() {
		return offScreen;
	}
	
	public double getRadius() {
		return getWidth()/2;
	}
}
