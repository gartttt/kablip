package game;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

public class Player extends Entity{

	private static double diameter;
	private static double canonWidth;
	private static double canonHeight;
	private double healthPoints = 100;
	private HealthBar hp;
	private static final double ENEMY_DAMAGE = 20;
	
	private static final int NUM_PARTICLES = 30;
	private static ArrayList<PlayerParticle> particleList;
	
	
	private boolean isDead = false;
	
	//Used to set variables when a new game is created
	private void resetDimensions() {
		diameter = Main.percentScreenWidth(7);
		canonWidth = Main.percentScreenWidth(4.5);
		canonHeight = Main.percentScreenHeight(4.5);
		setX(Main.percentScreenWidth(50)-diameter/2);
		setY(Main.percentScreenHeight(50)-diameter/2);
		setWidth(diameter);
		setHeight(diameter);
		setColor(Color.GREEN);
		hp = new HealthBar(healthPoints/100,Main.percentScreenWidth(50)-Main.percentScreenWidth(70)/2, 10, Main.percentScreenWidth(70), 40, true);
	}
	
	public Player() {
		super();
		resetDimensions();
	}

	@Override
	public void draw(Graphics2D g) {
		g.setColor(new Color(0, 255, 0));
		if(!isDead) {
			
			hp.draw(g);
			resetDimensions();
			g.setColor(getColor());
			g.fill(new Ellipse2D.Double(getX(), getY(), getWidth(), getHeight()));
			
			double shootAngle = -Math.atan2(getX()+getWidth()/2-Main.getMouseX(), getY()+getHeight()/2-Main.getMouseY()) - Math.PI/2;	
			if (shootAngle < 0) {
				shootAngle += Math.PI * 2;
			}
			
			//Makes the canon point towards the mouse
			AffineTransform oldTransform = g.getTransform();
			AffineTransform newTransform = g.getTransform();
			newTransform.translate(Main.percentScreenWidth(50), Main.percentScreenHeight(50));
			newTransform.rotate(shootAngle, 0, 0);
			g.setTransform(newTransform);
			g.fill(new Rectangle.Double(canonWidth/2, -canonHeight/2, canonWidth, canonHeight));
			g.setTransform(oldTransform);
		} else {
			for(int i = 0; i < NUM_PARTICLES; i++) {
				particleList.get(i).draw(g);
			}
		}
	}
	
	public double getCenterX() {
		return getX() + getWidth()/2; 
	}
	
	public double getCenterY() {
		return getY() + getWidth()/2;
	}
	
	public boolean collidesWith(Enemy e) {
		
		//Calculates collision with circle and rectangle
		boolean result;
		
		double circleDistanceX = Math.abs(getCenterX() - e.getX() - e.getWidth()/2);
	    double circleDistanceY = Math.abs(getCenterY() - e.getY() - e.getHeight()/2);

	    if (circleDistanceX > e.getWidth()/2 + diameter/2 || circleDistanceY > e.getHeight()/2 + diameter/2) { 
	    	result = false;
    	}	else if (circleDistanceX <= (e.getWidth()/2) || circleDistanceY <= (e.getHeight()/2)) { 
	    	result = true;
    	} else {
    		double cornerDistanceSquared = Math.pow((circleDistanceX - e.getWidth()/2),2) + Math.pow(circleDistanceY - e.getHeight()/2,2);
    	    result = cornerDistanceSquared <= Math.pow(diameter/2,2);
    	}
	    
		//Reduce health or die after touching enemy
	    if(result && !isDead) {
			healthPoints -= ENEMY_DAMAGE * (Enemy.MAX_SPLITS - e.getLevel() + 1);
			if(healthPoints <= 0) {
				isDead = true;
				particleList = new ArrayList<PlayerParticle>();
				for(int i = 0; i < NUM_PARTICLES; i++) {
					particleList.add(new PlayerParticle());
				}
			}
		}
		return result;
	}
	
	public boolean getIfDead() {
		return isDead;
	}
	
//	public boolean collidesWithPoint(double x, double y) {
//		return Math.abs(getX()+diameter/2 - x) < diameter/2 && Math.abs(getY()+diameter/2 - y) < diameter/2;
//	}
	
}
