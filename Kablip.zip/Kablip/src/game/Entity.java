package game;

import java.awt.Color;
import java.awt.Graphics2D;

//A class that represents game components and buttons which stores position, size, and color.
public abstract class Entity {
	private double x;
	private double y;
	private double width;
	private double height;
	private Color color;
	
	public Entity(){
		this.x = 0;
		this.y = 0;
		this.width = 0;
		this.height = 0;
		this.color = new Color(0, 0, 0);
	}
	
	public Entity(double size) {
		this.x = 0;
		this.y = 0;
		this.width = size;
		this.height = size;
		this.color = new Color(0, 0, 0);
	}
	
	public Entity(double size, Color color) {
		this.x = 0;
		this.y = 0;
		this.width = size;
		this.height = size;
		this.color = color;
	}
	
	public Entity(double x, double y, Color color) {
		this.x = x;
		this.y = y;
		this.width = 0;
		this.height = 0;
		this.color = color;
	}
	
	public Entity(double x, double y, double size) {
		this.x = x;
		this.y = y;
		this.width = size;
		this.height = size;

	}
	public Entity(double x, double y, double width, double height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	public Entity(double x, double y, double size, Color color) {
		this.x = x;
		this.y = y;
		this.width = size;
		this.height = size;
		this.color = color;
	}
	
	public Entity(double x, double y, double width, double height, Color color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
	}
	
	public abstract void draw(Graphics2D g);
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
	
	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}
	
}
