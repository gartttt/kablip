package game;

//import java.awt.Canvas;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
//import java.awt.FontMetrics;
//import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.font.TextAttribute;
import java.text.AttributedString;

public abstract class GameButton extends Entity{
	
	private String text;
	private boolean mouseOver;
	private double fontWidth;
	private Font font;
	private String gameState[];
	
	public GameButton(String text, double x, double y, int size, String gameState[], Graphics2D g2d) {
		super(size);
		
		font = new Font("", Font.PLAIN, size);
		fontWidth = Main.getFontWidth(text, font);
		setX(x - fontWidth/2);
		setY(y + size/2);
		setWidth(fontWidth);
    	
		
    	this.text = text;
		this.gameState = gameState;
    	mouseOver = false;
	}
	
//	Displays the button
	public void draw(Graphics2D g) {
		g.setFont(new Font("", Font.PLAIN, (int)getHeight()));
		g.setColor(Color.WHITE);
		AttributedString as = new AttributedString(text);
		double xPosition = getX();
		// Adds ">" to button when hovered over
		if(isHover(Main.getGameState(), true)) {
			as = new AttributedString("> "+text);
			as.addAttribute(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON, 2, text.length()+2);
			g.setFont(new Font("", Font.PLAIN, (int) getHeight()));
			xPosition -= Main.getFontWidth("> ", g.getFont()); //+18
		} else {
			as = new AttributedString(text);
			as.addAttribute(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
		}
		as.addAttribute(TextAttribute.FONT, new Font("Consolas", Font.PLAIN, (int) getHeight()));
		g.drawString(as.getIterator(), Math.round(xPosition), Math.round(getY()));
	}

	public abstract void onClick(boolean condition);
	
	public boolean isHover(String currentState, boolean condition) {
		//If the game is in the right state and the button is being hovered over return true
		boolean isRightState = false;
		for(String s: gameState) {
			if(s.equals(currentState)) {
				isRightState = true;
			}
		}
		if(!condition || !isRightState) {
			return false;
		}
		boolean result;
		mouseOver = Main.getMouseX() >= getX() && Main.getMouseX() <= getX() + getWidth() && Main.getMouseY() <= getY() && Main.getMouseY() >= getY() - getHeight();
		result = mouseOver;
		if(result) {
			Main.setTheCursor(new Cursor(Cursor.HAND_CURSOR));
		}
		return result;
	}
	
	public boolean checkClick(String currentState, boolean condition) {
		if(isHover(currentState, condition)) {
			Main.playSound("menu.wav");
			onClick(condition);
			return true;
		}
		return false;
	}

}
